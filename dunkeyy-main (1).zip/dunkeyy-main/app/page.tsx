import MainPage from "./components/main/page";

const Page = () => {
    return (
        <div className="p-4">
            <MainPage />
        </div>
    )
}

export default Page;