import { Logo } from "../_components/logo"
import { NavButton } from "../_components/navbutton"

export const Navbar = () => {

    return (
        <div className="navbar flex items-center justify-between px-1 sm:px-2 md:px-3 lg:px-4 xl:px-5">
            <Logo />
            <NavButton />
        </div>
    )
}