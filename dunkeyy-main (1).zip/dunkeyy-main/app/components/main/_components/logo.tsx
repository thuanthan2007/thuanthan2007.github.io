import Image from "next/image"

export const Logo = () => {

    return (
        <div className="flex items-center gap-2">
            <Image 
                src="/img/icon.svg"
                alt="icon"
                width={100}
                height={100}
                className="lg:w-20 lg:h-20 md:w-15 md:h-15 w-10 h-10 rounded-full aspect-video border-[3px] border-[#f0d0d0]"
            />
            <h1 className="text-lg font-bold lg:ml-3 ml-1 md:text-xl lg:text-2xl xl:text-3xl">Dunkeyy Fong</h1>
        </div>
    )
}