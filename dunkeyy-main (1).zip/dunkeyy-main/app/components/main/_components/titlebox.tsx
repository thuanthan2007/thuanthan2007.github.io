import { Box, Text } from "@chakra-ui/react"

export const TitleBox = () => {
    return (
        <div>
            <div className="mt-10 flex justify-center items-center">
                <Box className="bg-neutral-200 rounded-lg p-3">
                    <Text className="text-center px-1 text-sm lg:text-md font-mono">
                        Hello, I&apos;m Fong, I&apos;m Front-end Developer in Viet Nam...
                    </Text>
                </Box>
            </div>
            <div className="bg-neutral-500 w-full h-1 rounded-sm mt-6 lg:hidden"></div>
        </div>
    )
}