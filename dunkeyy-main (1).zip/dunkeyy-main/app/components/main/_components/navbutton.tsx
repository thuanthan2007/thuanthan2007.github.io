import { ButtonGroup, Button } from "@chakra-ui/button"
import {
    Menu,
    MenuButton,
    MenuList,
    MenuItem
} from "@chakra-ui/menu"
import { Bars3Icon } from "@heroicons/react/20/solid"
import { BriefcaseIcon, EnvelopeIcon, HomeIcon } from "@heroicons/react/24/solid"

export const NavButton = () => {
    return (

        // Sidebar
        <div className="flex items-center justify-center">
            <div className="hidden lg:block xl:block">
                <ButtonGroup>
                    <Button
                        className="bg-[#1f1d1d] text-white px-3 py-2 rounded-xl flex items-center"
                    >
                        <HomeIcon className="w-5 h-5 inline mr-2"/>
                        Home
                    </Button>
                    <Button
                        className="bg-[#1f1d1d] text-white px-3 py-2 rounded-xl flex items-center"
                    >
                        <EnvelopeIcon className="w-5 h-5 inline mr-2"/>
                        Post
                    </Button>
                    <Button
                        className="bg-[#1f1d1d] text-white px-3 py-2 rounded-xl flex items-center"
                    >
                        <BriefcaseIcon className="w-5 h-5 inline mr-2"/>
                        Work
                    </Button>
                </ButtonGroup>
            </div>
            
            {/* Drop Menu */}
            <div className="block lg:hidden xl:hidden">
                <Menu>
                    <MenuButton
                        as={Button}
                        className="p-2 bg-[#221f1f] ml-2 rounded-lg"
                    >
                        <Bars3Icon className="w-4 h-4 text-white" />
                    </MenuButton>
                    <MenuList className="bg-[#2d2c2c] p-3 rounded-lg">
                        <MenuItem className="p-2 mr-5">
                            <span className="text-white text-sm flex items-center">
                                <HomeIcon className="w-5 h-5 inline mr-2"/>
                                Home
                            </span>
                        </MenuItem>
                        <MenuItem className="p-2">
                            <span className="text-white text-sm flex items-center">
                                <EnvelopeIcon className="w-5 h-5 inline mr-2"/>
                                Post
                            </span>
                        </MenuItem>
                        <MenuItem className="p-2">
                            <span className="text-white text-sm flex items-center">
                                <BriefcaseIcon className="w-5 h-5 inline mr-2"/>
                                Work
                            </span>
                        </MenuItem>
                    </MenuList>
                </Menu>
            </div>
        </div>
    )
}