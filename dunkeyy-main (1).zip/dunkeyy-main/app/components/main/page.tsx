import { Heading } from "@chakra-ui/react";
import { Navbar } from "./Navbar/navbar";
import { TitleBox } from "./_components/titlebox";
import { MainForm } from "../MainPage/mainpage";

const MainPage = () => {
    return (
        <div className="h-full">
            <div>
                <Navbar />
                <TitleBox />
                <div className="lg:flex lg:items-center lg:justify-center mt-4">
                    <MainForm />
                </div>
            </div>
        </div>
    )
}

export default MainPage;