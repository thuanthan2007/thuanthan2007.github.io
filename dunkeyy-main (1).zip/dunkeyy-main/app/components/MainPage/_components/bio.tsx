import { Heading, Text } from "@chakra-ui/react"
import { BioCard } from "./biocard"

export const Bio = () => {
    return (
        <div className="mt-8">
            <Heading as="h3" className="text-xl font-jose underline decoration-slate-500 decoration-4 font-semibold">
                Bio
            </Heading>
            <div className="mt-4">
                <BioCard />
            </div>
        </div>
    )
}