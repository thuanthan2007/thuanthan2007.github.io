import { Heading } from "@chakra-ui/react";

export const HeadingText = () => {
    return (
        <div className="">
            <Heading as="h2" className="text-3xl font-poppins font-semibold">
                Dunkeyy Fong
            </Heading>
            <p className="font-rubik">I&apos;m learning FE developer in BTEC FPT School</p>
        </div>
    )
}