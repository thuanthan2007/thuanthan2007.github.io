import Image from "next/image"

export const UserLogo = () => {

    return (
        <div className="flex items-center justify-center mt-4 md:ml-6">
            <Image 
                src="/img/icon.svg"
                alt="icon"
                width={100}
                height={100}
                className=" w-[15vh] h-[15vh] rounded-full aspect-video border-[3px] border-[#f0d0d0]"
            />
        </div>
    )
}