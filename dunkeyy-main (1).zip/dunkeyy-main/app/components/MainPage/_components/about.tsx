import { Heading, Text } from "@chakra-ui/react"

export const About = () => {
    return (
        <div className="mt-5">
            <Heading
                as="h3"
                variant="section-title"
                className="text-xl font-jose underline decoration-slate-500 decoration-4 font-semibold"
            >
                About
            </Heading>
            <Text className="mt-2 font-rubik">
                Hello, I&apos;m Trong Phong, my nickname is <span className="bg-cyan-400 px-1 py-1 rounded-lg text-gray-100">DunkeyyFong</span>, Fong is a student and learning IT in Btec FPT Ha Noi. I spend a lot of time learning new languages ​​to improve my programming skills. And the main languages ​​I often learn and code are HTML, CSS, JavaScript. Sometimes I learn more about ReactJS, NextJS,...
            </Text>
        </div>
    )
}