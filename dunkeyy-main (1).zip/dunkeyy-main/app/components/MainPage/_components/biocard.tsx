import { Image, Text } from "@chakra-ui/react"
import {
    List,
    ListItem,
    ListIcon,
    UnorderedList
} from "@chakra-ui/react"
import { CalendarDaysIcon, ExclamationCircleIcon, MapPinIcon, TagIcon } from "@heroicons/react/24/solid"

export const BioCard = () => {
    return (
        <div className="bg-gradient-to-r from-cyan-200 to-blue-300 p-7 rounded-lg shadow-lg shadow-slate-700 gap-x-10 font-rubik justify-center">
            <div className="md:flex md:items-center md:justify-center md:gap-x-5">
                <div className="flex items-center justify-center">
                    <Image
                        src="./img/img-bio.jpeg"
                        className="w-[14vh] h-[14vh] rounded-full border-[3px] border-[#e7bebe] ml-2"
                    />
                </div>
                <div className="flex items-center justify-center mt-3 md:mt-0">
                    <div>
                        <h1 className="font-bold text-lg flex items-center">
                            <ExclamationCircleIcon className="w-5 h-5 inline mr-2" />
                            Trong Phong (Fong)
                        </h1>
                        <p className="text-sm">Developer is learning fullstack</p>
                    </div>
                </div>
            </div>
            <div className="mt-4 flex items-center justify-center">
                <div className="">
                    <div className="flex">
                        <h2 className="underline font-bold decoration-slate-600 decoration-3 flex">
                            <CalendarDaysIcon className="w-5 h-5 inline mr-2" />
                            Birth:
                        </h2>
                        <Text className="inline ml-2">05-01-2004</Text>
                    </div>
                    <div className="flex">
                        <h2 className="underline font-bold decoration-slate-600 decoration-3 flex">
                            <MapPinIcon className="w-5 h-5 inline mr-2" />
                            Born:
                        </h2>
                        <Text className="inline ml-2">Tu Son, Bac Ninh, Viet Nam</Text>
                    </div>
                    <p className="font-bold flex">
                        <TagIcon className="w-5 h-5 inline mr-2" />
                        Learning programming languages:
                    </p>
                    <UnorderedList>
                        <ListItem>C#</ListItem>
                        <ListItem>ReactJS</ListItem>
                        <ListItem>SwiftUI</ListItem>
                        <ListItem>NextJS</ListItem>
                    </UnorderedList>
                </div>
            </div>
        </div>
    )
}