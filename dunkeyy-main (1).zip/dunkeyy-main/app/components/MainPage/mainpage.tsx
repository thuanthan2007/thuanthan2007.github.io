import { About } from "./_components/about"
import { Bio } from "./_components/bio"
import { Contact } from "./_components/contact"
import { HeadingText } from "./_components/heading"
import { UserLogo } from "./_components/userlogo"

export const MainForm = () => {
    return (
        <div>
            <div className="md:flex md:items-center md:justify-center">
                <HeadingText />
                <UserLogo />
            </div>
            <div className="mt-3 md:mr-[30vh] md:ml-[30vh]">
                <About />
                <Bio />
                <Contact />
            </div>
        </div>
    )
}